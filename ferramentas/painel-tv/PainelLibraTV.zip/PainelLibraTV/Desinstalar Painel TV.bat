@echo off
chcp 65001 >nul
setlocal

set "DESTINO=%LOCALAPPDATA%\PainelLibraTV"
set "ATALHO=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Painel Libra TV.lnk"

echo Removendo o Painel Libra TV...

if exist "%ATALHO%" del /Q "%ATALHO%"
if exist "%DESTINO%" rmdir /S /Q "%DESTINO%"

echo.
echo Pronto -- o painel nao abre mais sozinho ao ligar o computador.
echo (Isso nao mexe na conta "Painel de TV" nem no site -- so tira a
echo  abertura automatica deste computador.)
echo.
pause
