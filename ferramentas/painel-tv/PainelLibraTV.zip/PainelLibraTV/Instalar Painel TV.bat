@echo off
chcp 65001 >nul
setlocal

set "ORIGEM=%~dp0"
set "DESTINO=%LOCALAPPDATA%\PainelLibraTV"

echo ============================================
echo   Instalando o Painel Libra na 2a tela
echo ============================================
echo.

if not exist "%ORIGEM%abrir-painel-tv.ps1" goto :faltaarquivo
if not exist "%ORIGEM%criar-atalho.ps1" goto :faltaarquivo

if not exist "%DESTINO%" mkdir "%DESTINO%"

copy /Y "%ORIGEM%abrir-painel-tv.ps1" "%DESTINO%\abrir-painel-tv.ps1" >nul
copy /Y "%ORIGEM%criar-atalho.ps1" "%DESTINO%\criar-atalho.ps1" >nul

if not exist "%DESTINO%\abrir-painel-tv.ps1" goto :falhoucopia
if not exist "%DESTINO%\criar-atalho.ps1" goto :falhoucopia

echo Arquivos copiados para: %DESTINO%
echo.

echo Criando atalho de inicializacao automatica...
powershell -NoProfile -ExecutionPolicy Bypass -File "%DESTINO%\criar-atalho.ps1"

echo.
echo ============================================
echo   Instalado! A partir do proximo login do
echo   Windows o painel abre sozinho na 2a tela.
echo ============================================
echo.
echo Repare que uma janela azul do PowerShell vai aparecer por uns
echo segundos antes do navegador abrir -- isso e normal (e de proposito,
echo pra nao parecer execucao escondida) e ela fecha sozinha.
echo.
echo IMPORTANTE: na primeira vez, faca login no painel com a conta de
echo perfil "Painel de TV" -- depois disso ele fica logado sozinho por
echo muito tempo (nao precisa logar de novo a cada reinicio).
echo.

set /p TESTAR="Quer abrir o painel agora pra testar? (S/N): "
if /I "%TESTAR%"=="S" (
  start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Normal -File "%DESTINO%\abrir-painel-tv.ps1"
)

echo.
pause
goto :fim

:faltaarquivo
echo ERRO: nao encontrei os arquivos do instalador do lado deste .bat
echo ^(abrir-painel-tv.ps1, criar-atalho.ps1^).
echo.
echo Isso costuma acontecer quando o .bat e rodado direto de DENTRO do
echo arquivo .zip, sem extrair antes -- af o Windows so abre esse
echo arquivo sozinho, sem os outros do lado.
echo.
echo CORRIGINDO: clique com o botao direito no arquivo PainelLibraTV.zip,
echo escolha "Extrair tudo..." ^(Extract All...^), abra a PASTA que isso
echo criar no disco, e rode o "Instalar Painel TV.bat" de DENTRO dela.
echo.
pause
goto :fim

:falhoucopia
echo ERRO: os arquivos nao foram copiados direito para %DESTINO%.
echo Confira se tem espaco em disco e se o antivirus nao bloqueou a copia,
echo e rode o instalador de novo.
echo.
pause
goto :fim

:fim
