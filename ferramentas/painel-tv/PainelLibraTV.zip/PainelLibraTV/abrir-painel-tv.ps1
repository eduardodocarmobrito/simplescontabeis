# Abre o Painel Contabil Libra (painellibra.com) em modo "app" (sem abas/barra de
# endereco), posicionado e maximizado na SEGUNDA tela (a nao-principal). Roda sozinho
# no login do Windows via o atalho criado em "Instalar Painel TV.bat".
#
# Essa janela do PowerShell fica visivel por alguns segundos (de proposito -- versao
# "sem esconder", pra nao parecer execucao escondida pro antivirus) e fecha sozinha
# assim que o navegador abrir.
#
# Pra funcionar sem precisar logar toda hora, faca login UMA VEZ nessa mesma janela com
# a conta de perfil "Painel de TV" -- a sessao dessa conta dura ~2 anos, entao depois do
# 1o login o painel abre direto sozinho a cada reinicio.

# URL do painel -- troque aqui se um dia mudar de dominio.
$url = "https://painellibra.com"

Write-Host "Painel Libra TV: aguardando o Windows organizar os monitores..."
Start-Sleep -Seconds 6

Add-Type -AssemblyName System.Windows.Forms
$telas = [System.Windows.Forms.Screen]::AllScreens

# "Segunda tela" = a que NAO e a principal. Só 1 monitor conectado -> usa essa mesma.
$alvo = $telas | Where-Object { -not $_.Primary } | Select-Object -First 1
if (-not $alvo) { $alvo = $telas[0] }
$b = $alvo.Bounds

# Acha o Edge ou o Chrome (nessa ordem -- o Edge ja vem instalado em todo Windows 10/11).
$candidatos = @(
  "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
  "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
  "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe",
  "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
  "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
  "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
)
$navegador = $candidatos | Where-Object { Test-Path $_ } | Select-Object -First 1

if ($navegador) {
  Write-Host "Abrindo o painel em $navegador na tela de $($b.Width)x$($b.Height) em ($($b.X),$($b.Y))..."
  # --app= abre uma janela dedicada (sem abas, sem barra de endereco) -- parece um app de
  # TV de verdade. --start-fullscreen tira toda a moldura. --window-position/--window-size
  # jogam a janela pra dentro da segunda tela antes de maximizar.
  $argumentos = @(
    "--app=$url",
    "--window-position=$($b.X),$($b.Y)",
    "--window-size=$($b.Width),$($b.Height)",
    "--start-fullscreen"
  )
  Start-Process -FilePath $navegador -ArgumentList $argumentos
} else {
  Write-Host "Edge/Chrome nao encontrado -- abrindo no navegador padrao (sem posicionar na 2a tela)."
  Start-Process $url
}
