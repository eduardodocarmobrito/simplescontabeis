# Cria o atalho na pasta "Inicializar" do Windows, apontando DIRETO pro powershell.exe
# (janela normal/visivel -- versao "sem esconder", de proposito, pra reduzir a chance de
# antivirus marcar como execucao escondida). Chamado só pelo instalador.

$pasta = Split-Path -Parent $MyInvocation.MyCommand.Path
$ps1 = Join-Path $pasta "abrir-painel-tv.ps1"
$startup = [Environment]::GetFolderPath("Startup")
$atalho = Join-Path $startup "Painel Libra TV.lnk"
$powershellExe = "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe"

$shell = New-Object -ComObject WScript.Shell
$link = $shell.CreateShortcut($atalho)
$link.TargetPath = $powershellExe
$link.Arguments = "-NoProfile -ExecutionPolicy Bypass -WindowStyle Normal -File `"$ps1`""
$link.WorkingDirectory = $pasta
$link.WindowStyle = 1  # 1 = janela normal (visivel), nao minimizada nem escondida
$link.Description = "Abre o Painel Contabil Libra na 2a tela ao ligar o computador"
$link.Save()

if (Test-Path $atalho) {
  Write-Host "Atalho criado em: $atalho"
} else {
  Write-Host "AVISO: nao consegui confirmar o atalho."
}
